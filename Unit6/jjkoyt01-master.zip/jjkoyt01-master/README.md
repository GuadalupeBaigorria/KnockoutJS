# jjkoyt01
Condicionales en KnockoutJS
